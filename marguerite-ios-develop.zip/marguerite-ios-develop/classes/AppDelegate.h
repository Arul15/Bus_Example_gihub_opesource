//
//  AppDelegate.h
//  marguerite
//
//  Created by Kevin Conley on 7/8/13.
//  Copyright (c) 2013 Cardinal Devs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (assign, nonatomic) BOOL autoUpdateInProgress;
@property (strong, nonatomic) UIWindow *window;

@end
