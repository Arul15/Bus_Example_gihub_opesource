//
//  Constants.m
//  marguerite
//
//  Created by Hypnotoad on 5/8/14.
//  Copyright (c) 2014 Cardinal Devs. All rights reserved.
//

#import "Constants.h"

@implementation Constants

NSString* const GTFS_DB_LAST_UPDATE_DATE_KEY = @"GTFS_DB_LAST_UPDATE_DATE_KEY";

@end
