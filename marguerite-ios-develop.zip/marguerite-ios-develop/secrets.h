//
//  secrets.h
//  marguerite
//
//  Created by Kevin Conley on 7/18/13.
//  Copyright (c) 2013 Cardinal Devs. All rights reserved.
//

#ifndef marguerite_secrets_h
#define marguerite_secrets_h

#define MARGUERITE_REALTIME_XML_FEED    @""
#define MARGUERITE_VEHICLE_IDS_URL      @""
#define GOOGLE_MAPS_API_KEY             @""
#define MARGUERITE_TRANSIT_DATA_URL     @""
#define TESTFLIGHT_APPLICATION_TOKEN    @""


#endif
