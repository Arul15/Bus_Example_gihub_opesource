//
//  MUtil.h
//  marguerite
//
//  Created by Kevin Conley on 7/21/13.
//  Copyright (c) 2013 Cardinal Devs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"

@interface MUtil : NSObject

+ (UIColor *) colorFromHexString:(NSString *)hexString;

@end
