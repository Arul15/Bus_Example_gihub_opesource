//
//  MStopTime.m
//  marguerite
//
//  Created by Kevin Conley on 7/24/13.
//  Copyright (c) 2013 Cardinal Devs. All rights reserved.
//

#import "MStopTime.h"

@implementation MStopTime

@end
